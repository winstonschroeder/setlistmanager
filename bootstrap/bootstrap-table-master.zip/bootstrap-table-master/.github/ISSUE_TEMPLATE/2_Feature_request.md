---
name: 🚀 Feature Request/Improvement
about: Ideas for new features and improvements
labels: feature-request
---

**Description**  
<!-- Description of the desired new feature. -->


<!-- Love bootstrap-table? Please consider supporting our collective:
👉  https://opencollective.com/bootstrap-table/donate -->