# Tools

## Install

```
yarn install
```

## List

* check-api: Check the docs API
* check-locale: Check the src locale
